from distutils.core import setup

setup(name='weather',
      version='1.0',
      py_modules=['weather', 'weather_fnc']
      )
